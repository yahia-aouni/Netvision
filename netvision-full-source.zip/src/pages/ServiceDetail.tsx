import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { services } from '../data/mockData';
const ServiceDetail: React.FC = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [selectedPackage, setSelectedPackage] = useState<'basic' | 'standard' | 'premium'>('standard');
  const [showPayment, setShowPayment] = useState(false);
  const service = services.find(s => s.id === id);
  if (!service) return <div className="p-8 text-center"><h2 className="text-2xl">الخدمة غير موجودة</h2><button onClick={() => navigate('/services')} className="btn-primary mt-4">تصفح الخدمات</button></div>;
  const pkgNames = { basic: 'الأساسية', standard: 'القياسية', premium: 'الاحترافية' };
  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4">
        <nav className="mb-6 flex gap-2 text-sm"><a href="/" className="text-gray-500">الرئيسية</a><span className="text-gray-400">/</span><a href="/services" className="text-gray-500">الخدمات</a><span className="text-gray-400">/</span><span>{service.category}</span></nav>
        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white rounded-xl overflow-hidden shadow-sm"><img src={service.image} alt={service.title} className="w-full aspect-video object-cover" /></div>
            <div className="bg-white rounded-xl p-6 shadow-sm">
              <div className="flex items-center gap-4 mb-4"><img src={service.seller.avatar} alt={service.seller.name} className="w-14 h-14 rounded-full" /><div><h1 className="text-2xl font-bold">{service.title}</h1><div className="flex items-center gap-2"><span>{service.seller.name}</span><span className="text-yellow-500">★ {service.rating}</span><span className="text-gray-400">({service.reviewsCount})</span></div></div></div>
            </div>
            <div className="bg-white rounded-xl p-6 shadow-sm"><h2 className="text-xl font-bold mb-4">وصف الخدمة</h2><p className="text-gray-600">{service.description}</p></div>
            <div className="bg-white rounded-xl p-6 shadow-sm"><h2 className="text-xl font-bold mb-6">الباقات</h2><div className="grid md:grid-cols-3 gap-6">{(['basic','standard','premium'] as const).map(pkg => <div key={pkg} className={`p-6 rounded-xl border-2 ${selectedPackage === pkg ? 'border-primary' : 'border-gray-200'}`}><h3 className="font-bold mb-4">الباقة {pkgNames[pkg]}</h3><ul className="space-y-2">{service.features[pkg].map((f,i) => <li key={i} className="flex items-center gap-2 text-sm text-gray-600"><span className="text-green-500">✓</span>{f}</li>)}</ul></div>)}</div></div>
          </div>
          <div>
            <div className="bg-white rounded-xl p-6 shadow-sm sticky top-24">
              <h3 className="text-xl font-bold mb-6">اختر الباقة</h3>
              <div className="space-y-3 mb-6">{(['basic','standard','premium'] as const).map(pkg => <label key={pkg} className={`flex items-center justify-between p-4 rounded-xl border-2 cursor-pointer ${selectedPackage === pkg ? 'border-primary bg-orange-50' : 'border-gray-200'}`}><div className="flex items-center gap-3"><input type="radio" checked={selectedPackage === pkg} onChange={() => setSelectedPackage(pkg)} className="w-4 h-4" /><div><p className="font-medium">{pkgNames[pkg]}</p><p className="text-sm text-gray-500">{service.deliveryTime[pkg]} أيام</p></div></div><span className="text-xl font-bold text-primary">{service.price[pkg]} دج</span></label>)}</div>
              <button onClick={() => setShowPayment(true)} className="btn-primary w-full">اطلب الآن</button>
              <p className="text-center text-sm text-gray-500 mt-4">الدفع آمن 100% عبر Baridimob</p>
              <div className="mt-6 pt-6 border-t"><h4 className="font-medium mb-4">عن البائع</h4><div className="flex items-center gap-3"><img src={service.seller.avatar} alt={service.seller.name} className="w-12 h-12 rounded-full" /><div><p className="font-medium">{service.seller.name}</p><p className="text-sm text-gray-500">{service.seller.completedOrders} مشروع</p></div></div></div>
            </div>
          </div>
        </div>
      </div>
      {showPayment && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center" onClick={() => setShowPayment(false)}>
          <div className="bg-white rounded-2xl w-full max-w-lg mx-4" onClick={e => e.stopPropagation()}>
            <div className="bg-gradient-to-r from-primary to-secondary p-6 text-white"><h2 className="text-2xl font-bold">إتمام الطلب</h2></div>
            <div className="p-6">
              <div className="bg-gray-50 rounded-xl p-4 mb-6"><div className="flex justify-between mb-2"><span>الباقة</span><span className="badge badge-primary">{pkgNames[selectedPackage]}</span></div><div className="flex justify-between pt-2 border-t"><span className="font-bold">المجموع</span><span className="text-2xl font-bold text-primary">{service.price[selectedPackage]} دج</span></div></div>
              <div className="flex items-center gap-3 bg-blue-50 p-4 rounded-xl mb-6"><div className="w-12 h-8 bg-gradient-to-r from-yellow-400 to-orange-500 rounded flex items-center justify-center"><span className="text-xs font-bold text-white">BM</span></div><div><p className="font-bold">الدفع بـ Baridimob</p><p className="text-sm text-gray-500">CIB • BNA • CCP</p></div></div>
              <div className="space-y-4 mb-6"><div><label className="block text-sm font-medium mb-2">رقم البطاقة</label><input type="text" placeholder="0000 0000 0000 0000" className="input-field font-mono" /></div><div className="grid grid-cols-2 gap-4"><div><label className="block text-sm font-medium mb-2">MM/YY</label><input type="text" placeholder="12/25" className="input-field font-mono" /></div><div><label className="block text-sm font-medium mb-2">CVV</label><input type="text" placeholder="123" className="input-field font-mono" /></div></div></div>
              <button onClick={() => { alert('تم إرسال طلبك بنجاح!'); setShowPayment(false); }} className="btn-primary w-full">ادفع {service.price[selectedPackage]} دج</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
export default ServiceDetail;